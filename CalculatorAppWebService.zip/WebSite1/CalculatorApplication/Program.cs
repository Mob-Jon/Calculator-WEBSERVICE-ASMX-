﻿using System;
using System.Collections.Generic;http://localhost:2330/CalculatorApplication/Form1.resx
using System.Linq;
using System.Windows.Forms;

namespace CalculatorApplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
