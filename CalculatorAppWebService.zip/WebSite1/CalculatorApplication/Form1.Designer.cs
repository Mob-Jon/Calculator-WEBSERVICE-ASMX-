﻿namespace CalculatorApplication
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNum = new System.Windows.Forms.Label();
            this.secondNum = new System.Windows.Forms.Label();
            this.txtBox_firstNum = new System.Windows.Forms.TextBox();
            this.txtBox_secondNum = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            this.subtract = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstNum
            // 
            this.firstNum.AutoSize = true;
            this.firstNum.Location = new System.Drawing.Point(38, 44);
            this.firstNum.Name = "firstNum";
            this.firstNum.Size = new System.Drawing.Size(66, 13);
            this.firstNum.TabIndex = 0;
            this.firstNum.Text = "First Number";
            // 
            // secondNum
            // 
            this.secondNum.AutoSize = true;
            this.secondNum.Location = new System.Drawing.Point(41, 97);
            this.secondNum.Name = "secondNum";
            this.secondNum.Size = new System.Drawing.Size(84, 13);
            this.secondNum.TabIndex = 1;
            this.secondNum.Text = "Second Number";
            // 
            // txtBox_firstNum
            // 
            this.txtBox_firstNum.Location = new System.Drawing.Point(142, 41);
            this.txtBox_firstNum.Name = "txtBox_firstNum";
            this.txtBox_firstNum.Size = new System.Drawing.Size(100, 20);
            this.txtBox_firstNum.TabIndex = 2;
            this.txtBox_firstNum.TextChanged += new System.EventHandler(this.txtBox_firstNum_TextChanged);
            // 
            // txtBox_secondNum
            // 
            this.txtBox_secondNum.Location = new System.Drawing.Point(142, 94);
            this.txtBox_secondNum.Name = "txtBox_secondNum";
            this.txtBox_secondNum.Size = new System.Drawing.Size(100, 20);
            this.txtBox_secondNum.TabIndex = 3;
            this.txtBox_secondNum.TextChanged += new System.EventHandler(this.txtBox_secondNum_TextChanged);
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(44, 156);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(75, 23);
            this.Add.TabIndex = 4;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // subtract
            // 
            this.subtract.Location = new System.Drawing.Point(167, 156);
            this.subtract.Name = "subtract";
            this.subtract.Size = new System.Drawing.Size(75, 23);
            this.subtract.TabIndex = 5;
            this.subtract.Text = "Subtract";
            this.subtract.UseVisualStyleBackColor = true;
            // 
            // multiply
            // 
            this.multiply.Location = new System.Drawing.Point(44, 206);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(75, 23);
            this.multiply.TabIndex = 6;
            this.multiply.Text = "Multiply";
            this.multiply.UseVisualStyleBackColor = true;
            // 
            // divide
            // 
            this.divide.Location = new System.Drawing.Point(167, 206);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(75, 23);
            this.divide.TabIndex = 7;
            this.divide.Text = "Divide";
            this.divide.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.divide);
            this.Controls.Add(this.multiply);
            this.Controls.Add(this.subtract);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.txtBox_secondNum);
            this.Controls.Add(this.txtBox_firstNum);
            this.Controls.Add(this.secondNum);
            this.Controls.Add(this.firstNum);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNum;
        private System.Windows.Forms.Label secondNum;
        private System.Windows.Forms.TextBox txtBox_firstNum;
        private System.Windows.Forms.TextBox txtBox_secondNum;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Button subtract;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button divide;
    }
}

