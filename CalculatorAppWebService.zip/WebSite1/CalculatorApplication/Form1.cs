﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CalculatorApplication
{
    public partial class Form1 : Form
    {
        private int numOne;
        private int numTwo;

        ServiceReference.ServiceSoapClient webServices = new ServiceReference.ServiceSoapClient();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            int addResult = webServices.Add(numOne, numTwo);
            MessageBox.Show(addResult.ToString());
        }

        private void txtBox_firstNum_TextChanged(object sender, EventArgs e)
        {
            numOne = Convert.ToInt32(txtBox_firstNum.Text);
        }

        private void txtBox_secondNum_TextChanged(object sender, EventArgs e)
        {
            numTwo = Convert.ToInt32(txtBox_secondNum);
        }

    }
}
